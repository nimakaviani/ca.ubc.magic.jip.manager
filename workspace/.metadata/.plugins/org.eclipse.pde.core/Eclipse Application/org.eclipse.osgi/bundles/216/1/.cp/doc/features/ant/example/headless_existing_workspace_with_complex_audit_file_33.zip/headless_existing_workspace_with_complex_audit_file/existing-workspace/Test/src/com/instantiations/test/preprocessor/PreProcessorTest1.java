package com.instantiations.test.preprocessor;

/**
 * Simple class for testing the preprocessor
 * <p>
 * Copyright (c) 2003, Instantiations, Inc.<br>
 * All Rights Reserved
 * 
 * @author Dan Rubel
 * @version $Revision$
 */
public class PreProcessorTest1 {

	/**
	 * Method test1.
	 */
	private void test1() {
		// do something
	}

	/**
	 * Method test2.
	 */
	private void test2() {
		// do something
	}

	/**
	 * Main entry point for the program
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		/* $codepro.preprocessor.if version < 2.1 $ */
		new PreProcessorTest1().test1();
		/* $codepro.preprocessor.elseif version >= 2.1 $
		new PreProcessorTest1().test2();
		$codepro.preprocessor.endif $ */
		
		// add a line that triggers 2 audit violations
		int local = 316;
	}

}