package com.instantiations.example.money;

public class CustomerUsage {

    public static String getFoo(Customer c) {
        if (c.getName().equals("John Doe"))
            return "bar";
        if (c.getZip() == 37)
            return "hello";
        return "foo";
    }
    
    public static Customer makeCustomer(int a, String b) {
        if (a == 1) return null;
        if (b.startsWith("z")) return new Customer ("Sam", 99999);
        return new Customer (b, a);
    }
}
