package com.instantiations.sample.auditrules.ui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.instantiations.assist.eclipse.analysis.audit.core.AuditRule;
import com.instantiations.assist.eclipse.analysis.ui.audit.editor.BasicAuditRuleEditor;
import com.instantiations.sample.auditrules.SampleAuditRule;

/**
 * Instances of the class <code>SampleAuditRuleEditor</code> implement
 * an editor that can be used to edit instances of the class
 * {@link SampleAuditRule}.
 * <p>
 * Copyright (c) 2003, Instantiations, Inc.<br>
 * All Rights Reserved
 *
 * @author Eric Clayberg
 * @version $Revision$
 */
public class SampleAuditRuleEditor extends BasicAuditRuleEditor
{
	/**
	 * The text field in which the user can enter the name prefix that will be looked for.
	 */
	protected Text prefixText;

	////////////////////////////////////////////////////////////////////////////
	//
	// UI Creation
	//
	////////////////////////////////////////////////////////////////////////////

	/**
	 * Create the widgets used to allow the user to edit the configuration
	 * parameters of the given audit rule. The widgets can be created as direct
	 * children of the given composite and the composite's layout manager can
	 * be directly set by this method.
	 *
	 * @param parent the parent for the editor widgets
	 */
	public void createEditor(Composite parent)
	{
		GridLayout layout;
		Label label;
		GridData data;

		layout = new GridLayout();
		layout.numColumns = 2;
		parent.setLayout(layout);

		createTwoColumnSeverityEditor(parent);

		label = new Label(parent, SWT.NONE);
		label.setText("Prefix");
		label.setLayoutData(new GridData());

		prefixText = new Text(parent, SWT.BORDER | SWT.SINGLE);
		prefixText.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
	}

	/**
	 * Fill the editor with parameter values for the specified audit rule
	 *
	 * @param auditRule the audit rule whose parameters will be edited
	 */
	public void fillEditor(AuditRule auditRule)
	{
		SampleAuditRule rule;

		super.fillEditor(auditRule);
		if (auditRule instanceof SampleAuditRule) {
			rule = (SampleAuditRule) auditRule;
			prefixText.setText(rule.getPrefix());
		}
	}

	////////////////////////////////////////////////////////////////////////////
	//
	// Editing
	//
	////////////////////////////////////////////////////////////////////////////

	/**
	 * The user has requested that the changes that were made be saved, so
	 * update the configuration parameters of the given audit rule to reflect
	 * the current state of the UI.
	 *
	 * @param auditRule the audit rule that is to be updated
	 */
	public void applyChanges(AuditRule auditRule)
	{
		SampleAuditRule rule;

		super.applyChanges(auditRule);
		if (auditRule instanceof SampleAuditRule) {
			rule = (SampleAuditRule) auditRule;
			rule.setPrefix(prefixText.getText());
		}
	}

	/**
	 * The user has requested that the user interface be updated to reflect the
	 * default settings for the configuration parameters. The given audit rule
	 * can be used to determine the appropriate default values.
	 *
	 * @param auditRule the audit rule associated with this editor
	 */
	public void restoreDefaults(AuditRule auditRule)
	{
		super.restoreDefaults(auditRule);
		prefixText.setText("foo");
	}
}