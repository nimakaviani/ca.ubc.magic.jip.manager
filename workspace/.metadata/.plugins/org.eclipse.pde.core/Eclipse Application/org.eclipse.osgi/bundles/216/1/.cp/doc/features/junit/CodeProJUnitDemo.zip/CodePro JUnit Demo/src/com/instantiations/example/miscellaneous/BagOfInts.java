/*
 * Created on Oct 8, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.instantiations.example.miscellaneous;

import java.io.Serializable;

/**
 * @author dcobb
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BagOfInts implements Serializable {
	public int A, B, C;

	public BagOfInts() {
		super();
	}

	public BagOfInts(int a, int b, int c)
	{
		A = a;
		B = b;
		C = c;
	}	

}
