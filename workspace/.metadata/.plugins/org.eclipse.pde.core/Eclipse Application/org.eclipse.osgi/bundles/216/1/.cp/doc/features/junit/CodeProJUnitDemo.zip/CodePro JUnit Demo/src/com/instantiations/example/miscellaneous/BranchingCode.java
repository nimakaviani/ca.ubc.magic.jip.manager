 /*
 * Created on Oct 6, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.instantiations.example.miscellaneous;

/**
 * @author dcobb
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BranchingCode {
	
	public static int primativeBranch(int x, int y, int z) {
		if (x == 3 && y == 5) return 17;
		if (x == 5) 
		{
			if (y == 7)
			{
				if(z > 20)
					return 11000;
				else if (z < 20)
					return 19;
				else
					return 56000;
			}
			else
			{
				if(z > 20)
					return 11001;
				else if (z < 20)
					return 191;
				else
					return 56001;
			}
		}
		else if (x == 7) 
		{
			if (y == 7)
			{
				if(z > 20)
					return 11002;
				else if (z < 20)
					return 12;
				else
					return 56002;
			}
			else
			{
				if(z > 20)
					return 11003;
				else if (z < 20)
					return 13;
				else
					return 56003;
			}
		}

		return -1;
	}

	public static int valueObjectBranch(BagOfInts bag) {

		if (bag.A == 33 && bag.B == 35) return 17;
		if (bag.A == 35) 
		{
			if (bag.B == 37)
			{
				if(bag.C > 320)
					return 11000;
				else if (bag.C < 320)
					return 19;
				else
					return 56000;
			}
			else
			{
				if(bag.C > 320)
					return 11001;
				else if (bag.C < 320)
					return 191;
				else
					return 56001;
			}
		}
		else if (bag.A == 37) 
		{
			if (bag.B == 37)
			{
				if(bag.C > 320)
					return 11002;
				else if (bag.C < 320)
					return 12;
				else
					return 56002;
			}
			else
			{
				if(bag.C > 320)
					return 11003;
				else if (bag.C < 320)
					return 13;
				else
					return 56003;
			}
		}

		return -1;
	}
	
	//add negative testing
}
