Sample Pattern Project
(c) Instantiations, Inc. 2003

1) Import the project into your Eclipse/WSAD workspace using the "File | Import | Existing Project into Workspace" command.

2) Select the "build.xml" file, right click and select the "Run Ant..." command, and then choose the "export" target to build the project.

3) Unzip the resulting SamplePatternPlugin.zip file into your Eclipse or WSAD\eclipse directory.

4) Shutdown and re-start Eclipse/WSAD.

5) Open the CodePro Pattern wizard and look for the "Sample" pattern.