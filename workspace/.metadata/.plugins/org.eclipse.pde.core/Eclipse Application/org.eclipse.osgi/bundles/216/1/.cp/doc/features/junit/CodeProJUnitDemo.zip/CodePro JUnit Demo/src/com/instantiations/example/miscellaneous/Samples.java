package com.instantiations.example.miscellaneous;

/**
 * The class <code>Samples</code> defines several sample methods.
 * <p>
 * Copyright (c) 2004, Instantiations, Inc.<br>
 * All Rights Reserved
 *
 * @author Eric Clayberg
 * @version $Revision: 1.0 $
 */
public class Samples
{
	public static String ABCD = "ABCD";
	public static int XYZ = 37;

	public static int foo (int arg) {
		if (arg == 5) return 17;
		if (arg == -3) return 3;
		return 9;
	}

	public static String bar (String arg) {
		arg = new String(arg);
		if (arg.equals("xyz")) return "abc";
		if (arg == "123") 
			return "456";
		else if (arg.equals(ABCD))
			return ABCD;
		return "foo";
	}

	public static String xyz (int arg) {
		if (arg == 5) return "abc";
		if (arg == 123)
			return "456";
		else if (arg == XYZ)
			return ABCD;
		return "foo"; 
	}
	
	public static int abc(int x, int y) {
		if (x == 3 && y == 5) return 17;
		if (x == 5) {
			if (y == 7)
				return 19;
			else
				return 21;
		} else if (x == 7) {
			if (y == 7)
				return 23;
			else
				return 25;
		}
		return -1;
	}

	public static int add (int i1, int i2) {
		return i1 + i2;
	}
}