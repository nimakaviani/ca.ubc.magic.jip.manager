package com.instantiations.example.money;

public class Customer
{
    private String _name;
    private int    _zip;

    public Customer (String name, int zip) {
        _name = name;
        _zip = zip;
    }

    public String getName () {
        return _name;
    }

    public int getZip () {
        return _zip;
    }
}