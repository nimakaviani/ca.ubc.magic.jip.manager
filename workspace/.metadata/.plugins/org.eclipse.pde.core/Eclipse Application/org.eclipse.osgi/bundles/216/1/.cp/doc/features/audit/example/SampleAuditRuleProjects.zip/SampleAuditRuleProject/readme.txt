Sample Audit Rule Project
(c) Instantiations, Inc. 2003

1) Import the project into your Eclipse/WSAD workspace using the "File | Import | Existing Project into Workspace" command.

2) The .classpath file is set up for WSAD 5.1. If you are using Eclipse 5.0, rename the ".classpath20" file to ".classpath".

3) Select the "build.xml" file, right click and select the "Run Ant..." command, and then choose the "export" target to build the project.

4) Unzip the resulting SampleAuditRulePlugin.zip file into your Eclipse or WSAD\eclipse directory.

5) Do steps 1-4 with the "Sample Audit Rule Editor Project"

6) Shutdown and re-start Eclipse/WSAD.

7) Open the "CodePro | Audit | Rules" preference page and look for the "Sample Group | Sample" audit rule.