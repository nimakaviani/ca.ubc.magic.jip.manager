package com.instantiations.example.money;

public class CustomerFactory
{
	public static Customer johnDoe() {
		return new Customer("John Doe", 12345);
	}
	public static Customer janeSmith() {
		return new Customer("Jane Smith", 98765);
	}
}