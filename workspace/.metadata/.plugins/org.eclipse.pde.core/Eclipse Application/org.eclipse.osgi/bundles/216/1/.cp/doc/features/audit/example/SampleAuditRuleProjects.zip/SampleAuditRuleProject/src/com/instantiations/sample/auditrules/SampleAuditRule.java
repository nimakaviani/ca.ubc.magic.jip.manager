package com.instantiations.sample.auditrules;

import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import com.instantiations.assist.eclipse.analysis.audit.core.AbstractCodeAuditor;
import com.instantiations.assist.eclipse.analysis.audit.core.AuditViolationImpl;
import com.instantiations.assist.eclipse.analysis.audit.rule.CompilationUnitAuditRule;
import com.instantiations.assist.eclipse.analysis.engine.core.AnalysisContext;
import com.instantiations.assist.eclipse.analysis.engine.core.AnalysisItem;
import com.instantiations.assist.eclipse.analysis.engine.core.Analyzer;

/**
 * Instances of the class <code>SampleAuditRule</code>
 * implement an audit rule used to find methods and types that
 * have a name starting with a specific prefix.
 * <p>
 * Copyright (c) 2003, Instantiations, Inc.<br>
 * All Rights Reserved
 *
 * @author Eric Clayberg
 * @version $Revision: 1.0 $
 */
public class SampleAuditRule extends CompilationUnitAuditRule
{
	////////////////////////////////////////////////////////////////////////////
	//
	// Preference Constants
	//
	////////////////////////////////////////////////////////////////////////////

	/**
	 * The suffix added to the preferences identifier to compose the name of
	 * the preference whose value is the name prefix that will be looked for
	 */
	protected static final String PREFIX_PREFERENCE_SUFFIX = ".prefix";

	////////////////////////////////////////////////////////////////////////////
	//
	// Constructors
	//
	////////////////////////////////////////////////////////////////////////////

	/**
	 * Initialize a newly created audit rule.
	 */
	public SampleAuditRule()
	{
		super();
	}

	////////////////////////////////////////////////////////////////////////////
	//
	// Accessing
	//
	////////////////////////////////////////////////////////////////////////////

	/**
	 * Return the name prefix that will be looked for.
	 *
	 * @return the name prefix that will be looked for
	 */
	public String getPrefix()
	{
		String preferenceName;

		preferenceName = getPreferenceIdentifier() + PREFIX_PREFERENCE_SUFFIX;
		getPreferenceStore().setDefault(preferenceName, "foo");
		return getPreferenceStore().getString(preferenceName);
	}

	/**
	 * Set the name prefix that will be looked for.
	 *
	 * @param prefix name prefix that will be looked for
	 */
	public void setPrefix(String prefix)
	{
		String preferenceName;

		preferenceName = getPreferenceIdentifier() + PREFIX_PREFERENCE_SUFFIX;
		getPreferenceStore().setValue(preferenceName, prefix);
	}

	/**
	 * Return <code>true</code> if this audit rule should be enabled by
	 * default.
	 *
	 * @return <code>true</code> if this audit rule should be enabled by default
	 */
	public boolean isEnabledByDefault()
	{
		return false;
	}

	/**
	 * Return the default severity of this audit rule, which must be one of the
	 * following defined constants: {@link #HIGH_SEVERITY},
	 * {@link #MEDIUM_SEVERITY}, or {@link #LOW_SEVERITY}.
	 *
	 * @return the default severity of this audit rule
	 */
	public int getDefaultSeverity()
	{
		return LOW_SEVERITY;
	}

	////////////////////////////////////////////////////////////////////////////
	//
	// Analyzer Creation
	//
	////////////////////////////////////////////////////////////////////////////

	/**
	 * Create an analyzer that can perform the analysis implied by this analysis
	 * item.
	 *
	 * @param context the context in which the analysis will be performed
	 *
	 * @return the analyzer that was created
	 */
	public Analyzer createAnalyzer(AnalysisContext context)
	{
		return new SampleCodeAuditor(context, this);
	}

	////////////////////////////////////////////////////////////////////////////
	//
	// Inner Classes
	//
	////////////////////////////////////////////////////////////////////////////

	/**
	 * Instances of the class <code>SampleCodeAuditor</code>
	 * implement a code auditor used to find methods and types that
     * have a name starting with a specific prefix.
	 * <p>
	 * Copyright (c) 2002, Instantiations, Inc.<br>
	 * All Rights Reserved
	 *
	 * @author Brian Wilkerson
	 */
	public class SampleCodeAuditor extends AbstractCodeAuditor
	{
		////////////////////////////////////////////////////////////////////////
		//
		// Constructors
		//
		////////////////////////////////////////////////////////////////////////

		/**
		 * Initialize a newly created analyzer to perform an analysis in the
		 * given context for the given analysis item.
		 *
		 * @param context the context in which the analysis is to be performed
		 * @param item the analysis item for which the analysis is being
		 *        performed
		 */
		public SampleCodeAuditor(AnalysisContext context, AnalysisItem item)
		{
			super(context, item);
		}

		////////////////////////////////////////////////////////////////////////
		//
		// Visiting
		//
		////////////////////////////////////////////////////////////////////////

		public boolean visit(MethodDeclaration node)
		{
			String prefix;
			int startIndex, endIndex;
			
			prefix = getPrefix();
			if (prefix.length() == 0) return true;

			if (node.getName().getIdentifier().startsWith(prefix)) {
				startIndex = node.getName().getStartPosition();
				endIndex = startIndex + node.getName().getLength();
				addViolation(new AuditViolationImpl(
					"com.instantiations.sample.auditrules.sample.method",
					SampleAuditRule.this,
					getContext().getCurrentTarget(),
					startIndex,
					endIndex,
					new String[] {
						node.getName().getIdentifier(),
						prefix,
					}));
			}
			return true;
		}

		public boolean visit(TypeDeclaration node)
		{
			String prefix;
			int startIndex, endIndex;
			
			prefix = getPrefix();
			if (prefix.length() == 0) return true;

			if (node.getName().getIdentifier().startsWith(prefix)) {
				startIndex = node.getName().getStartPosition();
				endIndex = startIndex + node.getName().getLength();
				addViolation(new AuditViolationImpl(
					"com.instantiations.sample.auditrules.sample.type",
					SampleAuditRule.this,
					getContext().getCurrentTarget(),
					startIndex,
					endIndex,
					new String[] {
						node.getName().getIdentifier(),
						prefix,
					}));
			}
			return true;
		}
	}
}