package com.instantiations.example.stack;

/** 
@inv (top >= 0 && top < max) 
*/
class CleanStack {
    private Object[] elems;
    private int top, max;

    /** 
    @pre (sz > 0) 
    @post (max == sz && elems != null) 
    */
    public CleanStack(int sz) {
        max = sz;
        elems = new Object[sz];
    }

    /** 
    @pre !isFull() 
    @post (top == $pre (int, top) + 1) && elems[top-1] == obj 
    */
    public void push(Object obj) {
        elems[top++] = obj;
    }
    /** 
    @pre !isEmpty() 
    @post (top == $pre (int, top) - 1) && $ret == elems[top] 
    */
    public Object pop() {
        return elems[--top];
    }
    /** 
    @post ($ret == (top == max)) 
    */
    public boolean isFull() {
        return top == max;
    }
    /** 
    @post ($ret == (top == 0)) 
    */
    public boolean isEmpty() {
        return top == 0;
    }
} // End MyStack 