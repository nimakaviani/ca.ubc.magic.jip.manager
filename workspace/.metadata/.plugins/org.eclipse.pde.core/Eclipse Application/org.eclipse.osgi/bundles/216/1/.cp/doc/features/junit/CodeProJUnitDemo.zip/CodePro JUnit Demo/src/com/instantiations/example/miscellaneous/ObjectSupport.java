/*
 * Created on Oct 6, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.instantiations.example.miscellaneous;

/**
 * @author dcobb
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ObjectSupport {

	public int testStrings(String p1, String p2)
	{
		if (p1 == null)
			return 0;
		else if (p2 == null)
			return 1;
			
		if (p1.compareTo("TOMCAT")== 0)
			return 2;
	
		return 65000;
	}
}
