package com.instantiations.example.stack;

class SimpleStack {
    private Object[] elems;
    private int top, max;

    public SimpleStack(int sz) {
        max = sz;
        elems = new Object[sz];
    }

    public void push(Object obj) {
        elems[top++] = obj;
    }
    public Object pop() {
        return elems[--top];
    }
    public boolean isFull() {
        return top == max;
    }
    public boolean isEmpty() {
        return top == 0;
    }
}